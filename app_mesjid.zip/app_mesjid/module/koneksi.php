<?php

$user = "root"; 
$pass = "";
$host = "localhost";
$db = "appmesjid";

		mysql_connect($host, $user, $pass) or die ("Koneksi Gagal");
		mysql_select_db($db) or die ("Database tidak Ditemukan");

?>