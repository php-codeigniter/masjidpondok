		<!-- Start content -->
        <div class="content">
            
			<div class="container-fluid">
					
					
						<div class="row">
									<div class="col-xl-12">
											<div class="breadcrumb-holder">
													<h1 class="main-title float-left">Data Riwayat Pengeluaran أشهدُ أنْ لا إلهَ إلاَّ الله. وأشهدُ أنَّ محمّدًا رسولُ الله.</h1>
													<ol class="breadcrumb float-right">
														<li class="breadcrumb-item">Home</li>
														<li class="breadcrumb-item active">Dashboard</li>
													</ol>
													<div class="clearfix"></div>
											</div>
									</div>
						</div>
						
						<!-- end row -->

						
						
				<div class="row">
				
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">						
							<div class="card mb-3">
								<div class="card-header">
									<h3><i class="fa fa-table"></i> 					
									<a href="#custom-modal" class="btn btn-primary m-r-5 m-b-10" data-target="#customModal" data-toggle="modal">Entry Data Pengeluaran</a>
									</h3>
								</div>
									
								<div class="card-body">
									<div class="table-responsive">
									<table id="example1" class="table table-bordered table-hover display">
										<thead>
											<tr>
												<th>No</th>
												<th>Tanggal</th>
												<th>Nama Pengeluaran</th>
												<th>Jumlah</th>
											</tr>
										</thead>										
										<tbody>
											<?php error_reporting(0);
	
		$no=1;
		$query = "SELECT * FROM tbl_data_pengeluaran";
		$result = mysql_query($query);
		if ($result === FALSE) {
		die(mysql_error());
		}
		while ($data = mysql_fetch_array($result))
			{
				 $totjumlah= $totjumlah+$data['jumlah_pengeluaran'];	
			echo "
					<tr>
						<td>" .$no. "</td>
						<td>" .$data['tanggal']. "</td>
						<td>" .$data['nama_pengeluaran']. "</td>
						<td> Rp. " .number_format($data['jumlah_pengeluaran'], 2, ',', '.'). " </td>
					</tr>";
					$no++;
			}
					echo"<tr>
					<td colspan='3'>
						<center>
						<b>Total Pengeluaran</b>
						</center>
					</td>
					<td align='left'><b> Rp. " .number_format($totjumlah, 2, ',', '.')."</b></td>
						
					</tr>";
					
					
					
						
						
          $query = "SELECT * from riwayat_donatur	";
		$result = mysql_query($query);
		if ($result === FALSE) {
		die(mysql_error());
		}
		while ($data1 = mysql_fetch_array($result))
			{
				 $totjumlah1= $totjumlah1+$data1['jumlah'];	
				
			
					$no++;
			}
					echo"<tr>
					<td align='center' colspan='3'>
						<center>
						<b> Kas Keuangan</b>
						</center>
					</td>
					<td align='left' ><b> Rp. " .number_format($totjumlah1, 2, ',', '.')."</b></td>
						
					</tr>";
						echo"<tr>
					<td align='center' colspan='3'>
						<center>
						<b>Sisa Kas Keuangan</b>
						</center>
					</td>
					<td align='left'><b> Rp. " .number_format($totjumlah1-$totjumlah, 2, ',', '.')."</b></td>
						
					</tr>";
					
			
		?>
		
		
		
									
										</tbody>
									</table>
									</div>
									
								</div>	

							</div><!-- end card-->					
						</div>
						
			

				</div>
							

									
							</div>			



            </div>
			<!-- END container-fluid -->

		</div>
		<!-- END content -->
		
		<?php 
		include ("page/modal_pengeluaran.php");
		?>
		
<!-- END main -->


<script src="assets/js/jquery.min.js"></script>



			
<script>
    $(document).ready(function() {
        $('.counter').counterUp({
            delay: 10,
            time: 1000
        });
    });
</script>	
<!-- END Java Script for this page -->

</body>
</html>