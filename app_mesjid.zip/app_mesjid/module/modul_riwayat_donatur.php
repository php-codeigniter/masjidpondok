<?php
require ("koneksi.php");

      $action = isset($_GET['action']) ? $_GET['action'] : null;

switch($action) {
	case "add" :
						$id_riwayat = $_POST['id_riwayat'];
						$id_donatur = $_POST['id_donatur'];
						$id_kategori = $_POST['id_kategori'];
						$jumlah = $_POST['jumlah'];
						$keterangan = $_POST['keterangan'];
						$tanggal = $_POST['tanggal'];
						
							
							
	$query = "SELECT * FROM riwayat_donatur WHERE id_donatur='$id_donatur' AND id_kategori='$id_kategori' AND tanggal='$tanggal'";
	$result = mysql_query($query) or die (mysql_error());

	if(mysql_num_rows($result) > 0){
		
	echo "<script type='text/javascript'>
					alert('Maaf Sumbangan Duplikat');
					window.location.href='../index.php?page=entry_donatur&id_donatur=$id_donatur';
				</script>";
	} 
	else {
				
				  
		$query = "INSERT INTO riwayat_donatur (id_riwayat,id_donatur,id_kategori,jumlah,keterangan,tanggal) 
				  VALUES ('$id_riwayat','$id_donatur','$id_kategori','$jumlah','$keterangan','$tanggal')";
		$result = mysql_query($query) or die (mysql_error());

				if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Sumbangan Berhasil ditambahkan');
					window.location.href='../index.php?page=entry_donatur&id_donatur=$id_donatur';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=entry_donatur&id_donatur=$id_donatur';
				</script>
			";
		}
		
		
		}
	break;

	case "delete" :
		
		$id_riwayat = $_GET['id_riwayat'];
		$query = "DELETE FROM t_jadwal_dinas WHERE id_riwayat='$id_riwayat'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Berhasil Dihapus');
					window.location.href='../index.php?page=jadwal_dinas';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=jadwal_dinas';
				</script>
			";
		}
	break;
	
	
	
	
		case "update" :
	$id_riwayat = $_POST['id_riwayat'];
	$status = $_POST['status'];
	         
		
			$query = "UPDATE t_jadwal_dinas SET id_riwayat='$id_riwayat',status='$status' WHERE id_riwayat='$id_riwayat'";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
				alert('Berhasil DiVerifikasi');
					window.location.href='../index.php?page=jadwal_dinas';	
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=jadwal_dinas';
				</script>
			";
		}
	break;
}
?>