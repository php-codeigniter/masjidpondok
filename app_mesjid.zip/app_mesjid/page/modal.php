								<!-- Modal -->
								<div class="modal fade custom-modal" id="customModal" tabindex="-1" role="dialog" aria-labelledby="customModal" aria-hidden="true">
								  <div class="modal-dialog" role="document">
									<div class="modal-content">
									  <div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel2">Form Input Data Donatur</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
										  <div class="modal-body">
										<div class="card-body">						
										<form method="post"  action="module/modul_donatur.php?action=add" id="tab" enctype="multipart/form-data">	
										 <div class="form-group">
                                                        <label>NIK/KTP</label>
                                                        <div>
                                                            <input data-parsley-type="number" type="number" name="nik" class="form-control" required placeholder="Entry NIK/KTP numbers"/>
                                                        </div>
                                                    </div>  
                                                    <div class="form-group">
                                                        <label for="userName">Nama<span class="text-danger">*</span></label>
                                                        <input type="text" name="nama" data-parsley-trigger="change" required placeholder="Enter user name" class="form-control" id="userName">
                                                    </div>
                                                   
                                                    <div class="form-group">		
													<label for="example1">
													Jenis Kelamin: 
													</label>
													<select class="form-control" name="jk">    
														<option value="Laki-Laki">Laki-Laki</option>
														<option value="Perempuan">Perempuan</option>
														
													</select>
													</div>
                                                                           
                                                    <div class="form-group">
                                                        <label>Alamat</label>
                                                        <div>
                                                            <textarea required name="alamat" class="form-control"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <input id="remember-1" type="checkbox" required>
                                                            <label for="remember-1"> Apakah Anda Setujuh Mengirim Data Ini</label>
                                                        </div>
                                                    </div>                                               
										<div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
										 <input type="submit" name="submit" value="Save changes" class="btn btn-primary"></button>
										<input type="hidden" name="id_donatur" >
									  </div>
                                        </form>			
										</div>
									  </div>
									
									</div>
								  </div>
								</div>
								
								
								