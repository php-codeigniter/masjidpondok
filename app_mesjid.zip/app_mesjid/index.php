
<?php

	
	require ("module/ceklogin.php");
	require ("module/koneksi.php");
	include ("page/header.php");

?>


       
       





    <?php
				@$page = isset($_GET['page']) ? $_GET['page'] : null; 
					if (file_exists("page/$page.php")) {
						require("page/$page.php");
					}
						else {
						require("page/home.php");
					}
		?>
		
<?php

	include ("page/footer.php");

?>
