<!-- END content-page -->
    
	<footer class="footer">
		<span class="text-right">
		Copyright 2019 Mesjid Az-Zahda Pondok Bahagia </a>
		</span>
		<span class="float-right">
		Powered by <a href="#"><b> IT Remaja Pondok Bahagia</b></a>
		</span>
	</footer>

</div>
<!-- END main -->

<script src="assets/js/modernizr.min.js"></script>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/moment.min.js"></script>
		
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

<script src="assets/js/detect.js"></script>
<script src="assets/js/fastclick.js"></script>
<script src="assets/js/jquery.blockUI.js"></script>
<script src="assets/js/jquery.nicescroll.js"></script>
<script src="assets/js/jquery.scrollTo.min.js"></script>
<script src="assets/plugins/switchery/switchery.min.js"></script>

<!-- App js -->
<script src="assets/js/pikeadmin.js"></script>

<!-- BEGIN Java Script for this page -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>

<script>								
$(document).ready(function() {
    $('.select2').select2();
});
</script>
<!-- END Jap-->



	<script>
		$(document).ready(function() {
			// data-tables
			$('#example1').DataTable();
					
			// counter-up
			$('.counter').counterUp({
				delay: 10,
				time: 600
			});
		} );		
	</script>
	
										<script>
											$(function() {
												$('input[name="singledatepicker"]').daterangepicker({
													singleDatePicker: true,
													showDropdowns: true
												});
												$('input[name="tanggal111"]').daterangepicker({
										singleDatePicker: true,
										showDropdowns: true
									});
											});
													
											</script>

</body>
</html>