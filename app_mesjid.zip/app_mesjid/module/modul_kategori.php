<?php
require ("koneksi.php");

      $action = isset($_GET['action']) ? $_GET['action'] : null;

switch($action) {
	case "add" :
						$id_kategori = $_POST['id_kategori'];
						$nama_kategori = $_POST['nama_kategori'];
						
							
				
				  
		$query = "INSERT INTO master_kategori (id_kategori,nama_kategori) 
				  VALUES ('$id_kategori','$nama_kategori')";
		$result = mysql_query($query) or die (mysql_error());

				if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Berhasil ditambahkan');
					window.location.href='../index.php?page=master_kategori';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=master_kategori';
				</script>
			";
		}
		
		
		
	break;

	case "delete" :
		
		$id_pengeluaran = $_GET['id_pengeluaran'];
		$query = "DELETE FROM t_jadwal_dinas WHERE id_pengeluaran='$id_pengeluaran'";
		$result = mysql_query($query);
		if ($result == true) {
			echo "
				<script type='text/javascript'>
					alert('Data Berhasil Dihapus');
					window.location.href='../index.php?page=jadwal_dinas';
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=jadwal_dinas';
				</script>
			";
		}
	break;
	
	
	
	
		case "update" :
	$id_pengeluaran = $_POST['id_pengeluaran'];
	$status = $_POST['status'];
	         
		
			$query = "UPDATE t_jadwal_dinas SET id_pengeluaran='$id_pengeluaran',status='$status' WHERE id_pengeluaran='$id_pengeluaran'";
		$result = mysql_query($query) or die (mysql_error());
		if ($result == true) {
			echo "
				<script type='text/javascript'>
				alert('Berhasil DiVerifikasi');
					window.location.href='../index.php?page=jadwal_dinas';	
				</script>
			";
		}
		else {
			echo "
				<script type='text/javascript'>
					alert('Proses Gagal');
					window.location.href='../index.php?page=jadwal_dinas';
				</script>
			";
		}
	break;
}
?>