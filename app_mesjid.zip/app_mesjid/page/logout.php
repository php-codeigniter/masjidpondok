<?php
require ("../module/koneksi.php");
session_start();
	unset($_SESSION['user']);
	echo "<script type='text/javascript'>
			alert('Anda Telah Keluar');
			window.location.href='../login.php';
		</script>";
?>