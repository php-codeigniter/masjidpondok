								<!-- Modal -->
								<div class="modal fade custom-modal" id="customModal" tabindex="-1" role="dialog" aria-labelledby="customModal" aria-hidden="true">
								  <div class="modal-dialog" role="document">
									<div class="modal-content">
									  <div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel2">Form Input Data Pengeluaran</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
										  <div class="modal-body">
										<div class="card-body">						
										<form method="post"  action="module/modul_pengeluaran.php?action=add" id="tab" enctype="multipart/form-data">	
	 
                                                    <div class="form-group">
                                                        <label for="userName">Tanggal Pengeluaran<span class="text-danger">*</span></label>
                                                        <input type="date" name="tanggal" data-parsley-trigger="change" required placeholder="Entry Tanggal" class="form-control" id="userName">
                                                    </div>
													
                                           
                                                                           
                                                    <div class="form-group">
                                                        <label>Nama Pengeluaran</label>
                                                        <div>
                                                            <textarea required name="nama_pengeluaran" class="form-control"></textarea>
                                                        </div>
                                                    </div>
													
													<div class="form-group">
                                                        <label for="userName">Jumlah Pengeluaran<span class="text-danger">*</span></label>
                                                        <input type="number" name="jumlah_pengeluaran" data-parsley-trigger="change" required placeholder="Entry Pengeluaran" class="form-control" id="userName">
                                                    </div>
													
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <input id="remember-1" type="checkbox" required>
                                                            <label for="remember-1"> Apakah Anda Setujuh Mengirim Data Ini</label>
                                                        </div>
                                                    </div>                                               
										<div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
										 <input type="submit" name="submit" value="Save changes" class="btn btn-primary"></button>
										<input type="hidden" name="id_pengeluaran" >
									  </div>
                                        </form>			
										</div>
									  </div>
									
									</div>
								  </div>
								</div>
								
								
								