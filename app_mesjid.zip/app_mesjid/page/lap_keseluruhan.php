       <div class="content">
            
			<div class="container-fluid">
					
						<div class="row">
									<div class="col-xl-12">
											<div class="breadcrumb-holder">
													<h1 class="main-title float-left">Laporan أشهدُ أنْ لا إلهَ إلاَّ الله. وأشهدُ أنَّ محمّدًا رسولُ الله.</h1>
													<ol class="breadcrumb float-right">
														<li class="breadcrumb-item">Home</li>
														<li class="breadcrumb-item active">Dashboard</li>
													</ol>
													<div class="clearfix"></div>
											</div>
									</div>
						</div>
						
						
						
						
						
						
						<div class="row">
			
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">						
						<div class="card mb-3">
							<div class="card-header">
								<h3>
							<i class="fa fa-database bigfonts" aria-hidden="true"></i> DATA LAPORAN KESELURUHAN 		<a role="button" href="#" class="btn btn-success pull-right"><span class="btn-label"><i class="fa fa-print bigfonts" aria-hidden="true"></i></span>Print</a>
								
			
                       </h3>  
						 </div>
								
									<div class="card-body">
									<div class="table-responsive">
									<table id="example1" class="table table-bordered table-hover display">
										<thead>
											<tr>
												<th>No</th>
												<th>Tanggal</th>
												<th>Nama Penyumbang</th>
												<th>Jenis Sumbangan</th>
												<th>Keterangan</th>
												<th>Jumlah</th>
											</tr>
										</thead>										
										<tbody>
											<?php error_reporting(0);
	
		$no=1;
	 
		$query = "SELECT riwayat_donatur.id_riwayat, riwayat_donatur.jumlah, riwayat_donatur.keterangan,riwayat_donatur.tanggal,
		master_kategori.nama_kategori,tbl_data_donatur.nama FROM riwayat_donatur 
		JOIN master_kategori ON riwayat_donatur.id_kategori = master_kategori.id_kategori 
		JOIN tbl_data_donatur ON riwayat_donatur.id_donatur = tbl_data_donatur.id_donatur
		";
		$result = mysql_query($query);
		if ($result === FALSE) {
		die(mysql_error());
		}
		while ($data = mysql_fetch_array($result))
			{
					 $totjumlah= $totjumlah+$data['jumlah'];
			echo "
					<tr>
						<td>" .$no. "</td>
						<td>" .$data['tanggal']. "</td>
						<td>" .$data['nama']. "</td>
						<td>" .$data['nama_kategori']. "</td>
						<td>" .$data['keterangan']. "</td>
						<td>Rp. " .number_format($data['jumlah'], 2, ',', '.'). "</td>
							
						
					</tr>";
					$no++;

			}
			
			echo"<tr>
					<td align='center' colspan='5'>
						<center>
						<b>Total Sumbangan</b>
						</center>
					</td>
					<td align='left'><b> Rp. " .number_format($totjumlah, 2, ',', '.')."</b></td>
						
					</tr>";
			
		?>
											
										</tbody>
									</table>
									</div>
									
								</div>	
                            </div>
							</div>
							</div>
						</div>
						</div>
                  

             
		
		
		










		




		