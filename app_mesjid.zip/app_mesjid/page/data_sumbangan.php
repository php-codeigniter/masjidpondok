		<!-- Start content -->
        <div class="content">
            
			<div class="container-fluid">
					
					
						<div class="row">
									<div class="col-xl-12">
											<div class="breadcrumb-holder">
													<h1 class="main-title float-left">Data Riwayat Sumbangan أشهدُ أنْ لا إلهَ إلاَّ الله. وأشهدُ أنَّ محمّدًا رسولُ الله.</h1>
													<ol class="breadcrumb float-right">
														<li class="breadcrumb-item">Home</li>
														<li class="breadcrumb-item active">Dashboard</li>
													</ol>
													<div class="clearfix"></div>
											</div>
									</div>
						</div>
						
						<!-- end row -->

				
						
				<div class="row">
				
						<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">						
							<div class="card mb-3">
								<div class="card-header">
									<h3><i class="fa fa-table"></i> 					
									<a href="#custom-modal" class="btn btn-primary m-r-5 m-b-10" data-target="#customModal" data-toggle="modal">Entry Data Sumbangan</a>
									</h3>
								</div>
									
								<div class="card-body">
									<div class="table-responsive">
									<table id="example1" class="table table-bordered table-hover display">
										<thead>
											<tr>
												<th>No</th>
												<th>NIK</th>
												<th>Nama</th>
												<th>Jenis Kelamin</th>
												<th>Alamat</th>
												<th>Action</th>
											</tr>
										</thead>										
										<tbody>
											<?php
	
		$no=1;
		$query = "SELECT * FROM tbl_data_donatur";
		$result = mysql_query($query);
		if ($result === FALSE) {
		die(mysql_error());
		}
		while ($data = mysql_fetch_array($result))
			{
					
			echo "
					<tr>
						<td>" .$no. "</td>
						<td>" .$data['nik']. "</td>
						<td>" .$data['nama']. "</td>
						<td>" .$data['jk']. "</td>
						<td>" .$data['alamat']. "</td>
							<td><a href='index.php?page=entry_donatur&id_donatur=".$data['id_donatur']."'><button type='button' class='btn btn-success btn-sm'><i class='fa fa-check'></i> Proses</button>
                            </td>
						
					</tr>";
					$no++;

			}
			
		?>
											
										</tbody>
									</table>
									</div>
									
								</div>														
							</div><!-- end card-->					
						</div>
						
			

				</div>
							

									
							</div>			



            </div>
			<!-- END container-fluid -->

		</div>
		<!-- END content -->
		
		<?php 
		include ("page/modal.php");
		?>