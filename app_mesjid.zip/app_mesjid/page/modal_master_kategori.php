								<!-- Modal -->
								<div class="modal fade custom-modal" id="customModal" tabindex="-1" role="dialog" aria-labelledby="customModal" aria-hidden="true">
								  <div class="modal-dialog" role="document">
									<div class="modal-content">
									  <div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel2">Form Input Master Kategori</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
										  <span aria-hidden="true">&times;</span>
										</button>
									  </div>
										  <div class="modal-body">
										<div class="card-body">						
										<form method="post"  action="module/modul_kategori.php?action=add" id="tab" enctype="multipart/form-data">	

													
													<div class="form-group">
                                                        <label for="userName">Nama Kategori<span class="text-danger">*</span></label>
                                                        <input type="text" name="nama_kategori" data-parsley-trigger="change" required placeholder="Entry Kategori" class="form-control" id="userName">
                                                    </div>
													
                                                    <div class="form-group">
                                                        <div class="checkbox">
                                                            <input id="remember-1" type="checkbox" required>
                                                            <label for="remember-1"> Apakah Anda Setujuh Mengirim Data Ini</label>
                                                        </div>
                                                    </div>                                               
										<div class="modal-footer">
										<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
										 <input type="submit" name="submit" value="Save changes" class="btn btn-primary"></button>
										<input type="hidden" name="id_kategori" >
									  </div>
                                        </form>			
										</div>
									  </div>
									
									</div>
								  </div>
								</div>
								
								
								