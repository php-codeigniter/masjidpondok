<script language="javascript">
alert("Silahkan Login Terlebih Dahulu");
top.location="../login.php";
</script>
