<?php 
session_start();
require ("koneksi.php");

$pass=md5($_POST['pass']);
$administrator = mysql_query("SELECT * FROM tbl_admin_panel WHERE user='".mysql_real_escape_string($_POST['user'])."' AND pass='$pass'");

$hitung_administrator = mysql_num_rows($administrator);

	
if ($hitung_administrator >= 1){
    $r = mysql_fetch_array($administrator);
    $_SESSION['user']     = $r['user'];
    $_SESSION['level']    = $r['level'];
   	 if($r['level'] == "administrator"){
		header('location:../index.php?page=home');
  }
 
     }else{
    echo "
		<script type='text/javascript'>
		alert('Maaf. Password Anda Masukkan Salah');
		window.location.href='../login.php';
		</script>
	";
}
?>




