-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2019 at 11:29 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `appmesjid`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
`comment_id` int(11) NOT NULL,
  `comment_subject` varchar(500) NOT NULL,
  `comment_text` text NOT NULL,
  `comment_status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_subject`, `comment_text`, `comment_status`) VALUES
(1, 'fgfgf', 'gfgfg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `master_kategori`
--

CREATE TABLE IF NOT EXISTS `master_kategori` (
`id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(115) NOT NULL,
  `pass` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_kategori`
--

INSERT INTO `master_kategori` (`id_kategori`, `nama_kategori`, `pass`) VALUES
(1, 'IURAN BULAN', 1),
(2, 'PEMBANGUNAN', 1),
(3, 'CELENGAN MESJID', 1);

-- --------------------------------------------------------

--
-- Table structure for table `riwayat_donatur`
--

CREATE TABLE IF NOT EXISTS `riwayat_donatur` (
`id_riwayat` int(11) NOT NULL,
  `id_donatur` int(2) NOT NULL,
  `id_kategori` varchar(250) NOT NULL,
  `jumlah` varchar(11) NOT NULL,
  `keterangan` text NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `riwayat_donatur`
--

INSERT INTO `riwayat_donatur` (`id_riwayat`, `id_donatur`, `id_kategori`, `jumlah`, `keterangan`, `tanggal`) VALUES
(2, 2, '2', '200000', 'fdf', '2019-03-08'),
(3, 2, '1', '20000', 'gg', '2019-03-07'),
(4, 1, '1', '30000', 'gfgf', '2019-03-01'),
(5, 3, '2', '500000', 'wed', '2019-03-07'),
(6, 1, '1', '8000000', 'fdgfg', '2019-03-20'),
(7, 3, '2', '776666', 'fr', '2019-03-20'),
(8, 3, '1', '600000', 'fgfg', '2019-03-20'),
(9, 4, '3', '600000', 'jj', '2019-03-20'),
(10, 4, '1', '60000', 'jkkkkk', '2019-03-20'),
(11, 4, '2', '300000', '-', '2019-03-24'),
(12, 6, '1', '3333', 'ee', '2019-03-31'),
(13, 6, '1', '323232', 'ee', '2019-04-01'),
(14, 6, '2', '4444', '4343', '2019-03-31'),
(15, 1, '1', '4444', 'dsdsd', '2019-04-02'),
(17, 1, '2', '5454', 'ere', '2019-04-02'),
(18, 1, '2', '767676', 'g', '2019-04-18');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_panel`
--

CREATE TABLE IF NOT EXISTS `tbl_admin_panel` (
`id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(500) NOT NULL,
  `level` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin_panel`
--

INSERT INTO `tbl_admin_panel` (`id`, `user`, `pass`, `level`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_data_donatur`
--

CREATE TABLE IF NOT EXISTS `tbl_data_donatur` (
`id_donatur` int(11) NOT NULL,
  `nik` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jk` varchar(100) NOT NULL,
  `alamat` varchar(500) NOT NULL,
  `tanggal` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_data_donatur`
--

INSERT INTO `tbl_data_donatur` (`id_donatur`, `nik`, `nama`, `jk`, `alamat`, `tanggal`, `status`) VALUES
(1, '34434', '34343', 'Laki-Laki', 'dds', NULL, 0),
(2, '73731245454656577', 'Baco', 'Perempuan', 'PONDOK BAHAGIA', NULL, 0),
(3, '73731245454', 'Alim', 'Perempuan', 'wdewe', NULL, 0),
(4, '43435454', 'Hamba Allah', 'Laki-Laki', 'fere', '2019-03-20 11:40:50', 0),
(5, '545454', 'cdff', 'Perempuan', 'dss', NULL, 0),
(6, '7565656576565775565', 'dsd', 'Perempuan', 'ds', NULL, 0),
(7, '23232', 'sx', 'Perempuan', 'zxz', NULL, 0),
(8, '32', 'dsd', 'Perempuan', 'dsd', NULL, 0),
(9, '65565', 'fgg', 'Laki-Laki', 'gf', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_data_pengeluaran`
--

CREATE TABLE IF NOT EXISTS `tbl_data_pengeluaran` (
`id_pengeluaran` int(11) NOT NULL,
  `nama_pengeluaran` varchar(500) NOT NULL,
  `tanggal` date NOT NULL,
  `jumlah_pengeluaran` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_data_pengeluaran`
--

INSERT INTO `tbl_data_pengeluaran` (`id_pengeluaran`, `nama_pengeluaran`, `tanggal`, `jumlah_pengeluaran`) VALUES
(1, 'Sabun Cuci', '2019-03-20', '10000'),
(2, 'Nasi Bungkus', '2019-03-20', '50000'),
(4, 'Bata', '2019-03-20', '650000'),
(5, 'Rambu Lalu lintas', '2019-03-20', '40000'),
(6, 'Pembangunan', '2019-03-20', '9000000'),
(7, 'Sabun Cuci', '2019-02-20', '100000'),
(8, 'Pembangunan', '2019-03-24', '2000000'),
(9, 'dff', '2019-03-31', '32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
 ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `master_kategori`
--
ALTER TABLE `master_kategori`
 ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `riwayat_donatur`
--
ALTER TABLE `riwayat_donatur`
 ADD PRIMARY KEY (`id_riwayat`);

--
-- Indexes for table `tbl_admin_panel`
--
ALTER TABLE `tbl_admin_panel`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_data_donatur`
--
ALTER TABLE `tbl_data_donatur`
 ADD PRIMARY KEY (`id_donatur`);

--
-- Indexes for table `tbl_data_pengeluaran`
--
ALTER TABLE `tbl_data_pengeluaran`
 ADD PRIMARY KEY (`id_pengeluaran`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `master_kategori`
--
ALTER TABLE `master_kategori`
MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `riwayat_donatur`
--
ALTER TABLE `riwayat_donatur`
MODIFY `id_riwayat` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `tbl_admin_panel`
--
ALTER TABLE `tbl_admin_panel`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tbl_data_donatur`
--
ALTER TABLE `tbl_data_donatur`
MODIFY `id_donatur` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `tbl_data_pengeluaran`
--
ALTER TABLE `tbl_data_pengeluaran`
MODIFY `id_pengeluaran` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
