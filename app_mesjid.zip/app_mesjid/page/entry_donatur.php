       <div class="content">
            
			<div class="container-fluid">
					
						<div class="row">
									<div class="col-xl-12">
											<div class="breadcrumb-holder">
													<h1 class="main-title float-left">Dashboard</h1>
													<ol class="breadcrumb float-right">
														<li class="breadcrumb-item">Home</li>
														<li class="breadcrumb-item active">Dashboard</li>
													</ol>
													<div class="clearfix"></div>
											</div>
									</div>
						</div>
						
						
						
						
						
						
						<div class="row">
			
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">						
						<div class="card mb-3">
							<div class="card-header">
								<h3>
							
								
								    <?php
						$id_donatur = isset($_GET['id_donatur']) ? $_GET['id_donatur'] : null; 
				$query = "SELECT * FROM tbl_data_donatur where id_donatur='".mysql_real_escape_string($id_donatur)."'";
			$result = mysql_query($query);
			if ($result === FALSE) {
				die(mysql_error());
				}
			$data = mysql_fetch_array($result);{
		?>    
	  <center>   <button class="btn btn-info" data-toggle="collapse" data-target="#demos"> <h6><i class="pe-7s-folder"></i>    Entry Data Riwayat Sumbangan  ( <?php echo $data['nama']; ?> <?php echo $data['nik']; ?> )</h6></button></center>

								<?php 
}
//mysql_close($host);
?>  	
                       </h3>  
						 </div>
								
							<div class="card-body">
                           
						   
						   
						   
						   
						   
						   
							
										<div id="demos" class="collapse">		

								<form method="post" action="module/modul_riwayat_donatur.php?action=add" id="tab" enctype="multipart/form-data">                                   	
								   
								   
								   
								   
								   
										<div class="row">
										
											
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label><i class="pe-7s-folder"></i>  Kategori Sumbangan </label><br>
										<select class="form-control" id="id_kategori" name="id_kategori"> 										<option value="">Kategori  Please Select</option>
											<?php
											$query = mysql_query("SELECT * FROM master_kategori ORDER BY id_kategori");
												while ($row = mysql_fetch_array($query)) {
												?>
											<option value="<?php echo $row['id_kategori']; ?>">
											 <?php echo $row['nama_kategori']; ?> 
											</option>
											<?php
												}
											?>
										</select>
                                            </div>
                                        </div>
										 <div class="col-md-6">
                                            <div class="form-group">
                                       <label><i class="pe-7s-folder"></i>  Tanggal </label><br>				
								<input type="date" class="form-control" name="tanggal" />
 
								<script>
								$(function() {
									$('input[name="tanggal11"]').daterangepicker({
										singleDatePicker: true,
										showDropdowns: true
									});
								});
								</script>
											
											</br>

                                            </div>
                                        </div>
                                    </div>
									
									
									
									
									
										<div class="row">
										 <div class="col-md-6">
                                            <div class="form-group">
                                                <label><i class="pe-7s-folder"></i>  Jumlah Sumbangan</label>
                                              <input type="number" name="jumlah" id="jumlah" class="form-control" placeholder="Input Jumlah Sumbangan" required>

                                            </div>
                                        </div>
											
                                     
                                    </div>
									
									
									
									<div class="row">
									 <div class="col-md-6">
                                            <div class="form-group">
                                                <label><i class="pe-7s-folder"></i>  Keterangan</label>
									               <textarea class="form-control"  name="keterangan" id="txtEditor" placeholder="Input Keterangan Sumbangan / Donatur" ></textarea>

                                            </div>
                                        </div>
                                        </div>
									
									
									

								
									
									
											
												<ul class="nav nav-tabs" id="myTabdukumen">
													
												</ul>
												<div class="tab-content">
													<div class="tab-pane active" id="home"></div>
													<div class="tab-pane" id="profile">
													
													
													
													
													
													</div>
													<div class="tab-pane" id="messages">
													
													
													
													
													
													
													</div>
													<div class="tab-pane" id="settings">
													
													
													
													
													
													</div>
												</div>
				
									
									
								
								

									<div class="btn-toolbar">
													<i class="icon-save"><input type="submit" name="submit" value="Save" button class="btn btn-primary  pull-right" ></i></button>
											<input type="hidden" name="id_donatur" class="input-xlarge" value="<?php echo $data['id_donatur']; ?>">
											<input type="hidden" name="id_riwayat" id="id_riwayat" class="input-xlarge">
												</div>
									
                                </form>
									
								</div>
								
								
								
								
									<div class="card-body">
									<div class="table-responsive">
									<table id="example1" class="table table-bordered table-hover display">
										<thead>
											<tr>
												<th>No</th>
												<th>Tanggal</th>
												<th>Jenis Sumbangan</th>
												<th>Keterangan</th>
												<th>Jumlah</th>
											</tr>
										</thead>										
										<tbody>
											<?php error_reporting(0);
	
		$no=1;
		$id_donatur = isset($_GET['id_donatur']) ? $_GET['id_donatur'] : null; 
		$query = "SELECT riwayat_donatur.id_riwayat, riwayat_donatur.jumlah, riwayat_donatur.keterangan,riwayat_donatur.tanggal,
		master_kategori.nama_kategori FROM riwayat_donatur 
		JOIN master_kategori ON riwayat_donatur.id_kategori = master_kategori.id_kategori 
		JOIN tbl_data_donatur ON riwayat_donatur.id_donatur = tbl_data_donatur.id_donatur
		where riwayat_donatur.id_donatur='$id_donatur'";
		$result = mysql_query($query);
		if ($result === FALSE) {
		die(mysql_error());
		}
		while ($data = mysql_fetch_array($result))
			{
					 $totjumlah= $totjumlah+$data['jumlah'];
			echo "
					<tr>
						<td>" .$no. "</td>
						<td>" .$data['tanggal']. "</td>
						<td>" .$data['nama_kategori']. "</td>
						<td>" .$data['keterangan']. "</td>
						<td>Rp. " .number_format($data['jumlah'], 2, ',', '.'). "</td>
							
						
					</tr>";
					$no++;

			}
			
			echo"<tr>
					<td align='center' colspan='4'>
						<center>
						<b>Total Sumbangan</b>
						</center>
					</td>
					<td align='left'><b> Rp. " .number_format($totjumlah, 2, ',', '.')."</b></td>
						
					</tr>";
			
		?>
											
										</tbody>
									</table>
									</div>
									
								</div>	
								
								
								
								
								
								
								
								
								

                            </div>
							</div>
							</div>
						</div>
						</div>
						</div>
                  

             
		
		
		










		




		